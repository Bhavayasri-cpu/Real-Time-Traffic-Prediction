import random

def predict_traffic():
    status = ['Heavy Traffic', 'Moderate Traffic', 'Light Traffic']
    return random.choice(status)